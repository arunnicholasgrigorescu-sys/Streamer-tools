package com.streamertools;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parsing and formatting helpers for DonutSMP-style amounts ("5k", "1.5m", "2b") and durations. */
public final class Money {
    private Money() {}

    private static final Pattern DURATION = Pattern.compile("^(?:(\\d+)h)?(?:(\\d+)m)?(?:(\\d+)s?)?$");

    /** Parses "1500", "1,500", "1.5k", "2m", "3b", "1t". Returns NaN when invalid or negative. */
    public static double parse(String input) {
        if (input == null) return Double.NaN;
        String t = input.trim().toLowerCase(Locale.ROOT)
                .replace(",", "").replace("_", "").replace("$", "").replace("%", "").replace(" ", "");
        if (t.isEmpty()) return Double.NaN;
        double mult = 1;
        char last = t.charAt(t.length() - 1);
        switch (last) {
            case 'k' -> mult = 1e3;
            case 'm' -> mult = 1e6;
            case 'b' -> mult = 1e9;
            case 't' -> mult = 1e12;
            default -> { }
        }
        if (mult != 1) t = t.substring(0, t.length() - 1);
        try {
            double v = Double.parseDouble(t) * mult;
            return (Double.isFinite(v) && v >= 0) ? v : Double.NaN;
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    /** Parses "90", "90s", "5m", "1h30m", "1:30" (m:ss) into seconds. Returns -1 when invalid. */
    public static long parseSeconds(String input) {
        if (input == null) return -1;
        String t = input.trim().toLowerCase(Locale.ROOT).replace(" ", "");
        if (t.isEmpty()) return -1;
        try {
            if (t.contains(":")) {
                String[] p = t.split(":");
                if (p.length == 2) return Long.parseLong(p[0]) * 60 + Long.parseLong(p[1]);
                if (p.length == 3) return Long.parseLong(p[0]) * 3600 + Long.parseLong(p[1]) * 60 + Long.parseLong(p[2]);
                return -1;
            }
            Matcher m = DURATION.matcher(t);
            if (!m.matches()) return -1;
            long h = m.group(1) == null ? 0 : Long.parseLong(m.group(1));
            long min = m.group(2) == null ? 0 : Long.parseLong(m.group(2));
            long s = m.group(3) == null ? 0 : Long.parseLong(m.group(3));
            return h * 3600 + min * 60 + s;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** 1234567 -> "1.23M". */
    public static String fmt(double v) {
        double a = Math.abs(v);
        String sign = v < 0 ? "-" : "";
        if (a >= 1e12) return sign + trim(a / 1e12) + "T";
        if (a >= 1e9) return sign + trim(a / 1e9) + "B";
        if (a >= 1e6) return sign + trim(a / 1e6) + "M";
        if (a >= 1e3) return sign + trim(a / 1e3) + "K";
        return sign + trim(a);
    }

    public static String fmtSigned(double v) {
        return (v >= 0 ? "+" : "-") + fmt(Math.abs(v));
    }

    /** 83 -> "1:23", 3700 -> "1:01:40". */
    public static String fmtTime(long totalSeconds) {
        if (totalSeconds < 0) totalSeconds = 0;
        long h = totalSeconds / 3600;
        long m = (totalSeconds % 3600) / 60;
        long s = totalSeconds % 60;
        return h > 0
                ? String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s)
                : String.format(Locale.ROOT, "%d:%02d", m, s);
    }

    private static String trim(double v) {
        String s = String.format(Locale.ROOT, "%.2f", v);
        if (s.contains(".")) s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }
}
