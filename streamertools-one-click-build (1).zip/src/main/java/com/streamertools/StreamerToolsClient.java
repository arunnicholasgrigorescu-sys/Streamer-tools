package com.streamertools;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public class StreamerToolsClient implements ClientModInitializer {
    public static final String MOD_ID = "streamertools";

    private static KeyMapping openKey;
    private static KeyMapping hudKey;

    @Override
    public void onInitializeClient() {
        ToolsState.I.load();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.streamertools.open", InputConstants.Type.KEYSYM, InputConstants.KEY_U, category));
        hudKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.streamertools.hud", InputConstants.Type.KEYSYM, InputConstants.KEY_I, category));

        // Overlay for viewers
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "overlay"),
                Hud::render);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ToolsState.I.tick();

            while (openKey.consumeClick()) {
                if (client.player != null) client.gui.setScreen(new ToolsScreen());
            }
            while (hudKey.consumeClick()) {
                ToolsState.I.d.hud = !ToolsState.I.d.hud;
                ToolsState.I.save();
                if (client.player != null) {
                    client.player.sendSystemMessage(Component.literal(
                            "[StreamerTools] HUD " + (ToolsState.I.d.hud ? "ON" : "OFF")));
                }
            }
        });

        // "!bid 5k" typed by viewers is picked up from incoming chat (read only, nothing is ever sent)
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) ToolsState.I.onChatLine(message.getString());
        });
    }
}
