package com.streamertools;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * All mod state and logic. Nothing here sends chat messages or commands to the server:
 * bids are entered by hand or read from incoming chat, and gambling payouts are paid by the streamer manually.
 */
public final class ToolsState {
    public static final ToolsState I = new ToolsState();

    private static final Logger LOG = LoggerFactory.getLogger("streamertools");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern CHAT_BID =
            Pattern.compile("([A-Za-z0-9_]{3,16})\\W{0,8}!bid\\s+(\\S+)", Pattern.CASE_INSENSITIVE);

    // ---- games ----
    public static final String[] GAMES = {"Coin Flip", "High / Low (1-100)", "Pick a Number (1-6)"};
    public static final String[][] CALLS = {
            {"Heads", "Tails"},
            {"High (51-100)", "Low (1-50)"},
            {"1", "2", "3", "4", "5", "6"}
    };
    /** Fair payout multiplier (stake included) before the house edge is applied. */
    public static final double[] BASE_MULT = {2, 2, 6};

    /** Everything that is saved to config/streamertools.json. */
    public static final class Data {
        public boolean hud = true;
        public boolean chatBids = true;
        public boolean antiSnipe = true;

        // form fields (kept so they survive closing the screen)
        public String fItem = "";
        public String fValue = "";
        public String fMin = "";
        public String fTime = "60";
        public String fBidder = "";
        public String fBidAmt = "";
        public String fPlayer = "";
        public String fBet = "";
        public String fEdge = "5";

        public int gameIdx = 0;
        public int callIdx = 0;

        // running totals
        public double auctionProfit = 0;
        public double gambleProfit = 0;
        public int auctionsDone = 0;
        public int gamesPlayed = 0;
        public List<String> log = new ArrayList<>();
    }

    public record Bid(String bidder, double amount) {}

    public Data d = new Data();

    // ---- live auction (not saved) ----
    public boolean running = false;
    public String aItem = "";
    public double aValue = 0;
    public double aMin = 0;
    public long endMs = 0;
    public final List<Bid> bids = new ArrayList<>();
    public String status = "";
    public String lastAnnounce = "";

    // ---- last gambling result (not saved) ----
    public String gameMsg = "";
    public boolean lastGameHouseWon = true;

    private ToolsState() {}

    // ================= persistence =================

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("streamertools.json");
    }

    public void load() {
        try {
            Path p = file();
            if (Files.exists(p)) {
                Data x = GSON.fromJson(Files.readString(p), Data.class);
                if (x != null) {
                    d = x;
                    if (d.log == null) d.log = new ArrayList<>();
                    d.gameIdx = Math.floorMod(d.gameIdx, GAMES.length);
                }
            }
        } catch (Exception e) {
            LOG.warn("Could not read streamertools.json, using defaults", e);
        }
    }

    public void save() {
        try {
            Files.writeString(file(), GSON.toJson(d));
        } catch (IOException e) {
            LOG.warn("Could not save streamertools.json", e);
        }
    }

    // ================= helpers =================

    public double totalProfit() {
        return d.auctionProfit + d.gambleProfit;
    }

    private void addLog(String line) {
        d.log.add(0, line);
        while (d.log.size() > 60) d.log.remove(d.log.size() - 1);
    }

    private void notifyLocal(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[StreamerTools] " + text));
    }

    public void resetStats() {
        d.auctionProfit = 0;
        d.gambleProfit = 0;
        d.auctionsDone = 0;
        d.gamesPlayed = 0;
        d.log.clear();
        gameMsg = "";
        save();
    }

    public String summary() {
        return String.format(Locale.ROOT,
                "Stream profit: %s (auctions %s over %d, gambling %s over %d games)",
                Money.fmtSigned(totalProfit()), Money.fmtSigned(d.auctionProfit), d.auctionsDone,
                Money.fmtSigned(d.gambleProfit), d.gamesPlayed);
    }

    // ================= auction =================

    public Bid topBid() {
        Bid top = null;
        for (Bid b : bids) if (top == null || b.amount() > top.amount()) top = b;
        return top;
    }

    public long millisLeft() {
        return Math.max(0, endMs - System.currentTimeMillis());
    }

    /** Estimated profit if the auction ended right now: top bid minus the item's value. */
    public double projectedProfit() {
        Bid top = topBid();
        return top == null ? 0 : top.amount() - aValue;
    }

    public void startAuction() {
        String item = d.fItem.trim();
        double value = Money.parse(d.fValue.isBlank() ? "0" : d.fValue);
        double min = Money.parse(d.fMin.isBlank() ? "0" : d.fMin);
        long secs = Money.parseSeconds(d.fTime);
        if (item.isEmpty()) { status = "Enter an item name (or press 'Use held item')."; return; }
        if (Double.isNaN(value)) { status = "Item value is not a valid amount."; return; }
        if (Double.isNaN(min)) { status = "Minimum bid is not a valid amount."; return; }
        if (secs <= 0) { status = "Time is invalid. Try 90, 5m or 1h30m."; return; }

        aItem = item;
        aValue = value;
        aMin = min;
        bids.clear();
        endMs = System.currentTimeMillis() + secs * 1000L;
        running = true;
        status = "Auction started: " + item + " for " + Money.fmtTime(secs) + ", min bid " + Money.fmt(min) + ".";
        lastAnnounce = "Bid war started! " + item + " - minimum bid " + Money.fmt(min)
                + ", ends in " + Money.fmtTime(secs) + ".";
    }

    /** Returns null on success, otherwise the reason the bid was rejected. */
    public String placeBid(String bidder, double amount) {
        if (!running) return "No auction is running.";
        if (bidder == null || bidder.isBlank()) return "Enter a bidder name.";
        if (Double.isNaN(amount) || amount <= 0) return "Invalid bid amount.";
        if (amount < aMin) return "Below the minimum bid of " + Money.fmt(aMin) + ".";
        Bid top = topBid();
        if (top != null && amount <= top.amount()) return "Must beat the top bid of " + Money.fmt(top.amount()) + ".";

        bids.add(new Bid(bidder.trim(), amount));
        long now = System.currentTimeMillis();
        boolean extended = false;
        if (d.antiSnipe && endMs - now < 10_000L) {
            endMs = now + 10_000L;
            extended = true;
        }
        status = "New top bid: " + Money.fmt(amount) + " by " + bidder.trim() + (extended ? " (time extended)" : "");
        return null;
    }

    public void cancelAuction() {
        if (!running) return;
        running = false;
        status = "Auction cancelled. Nothing was recorded.";
    }

    public void endAuctionNow() {
        if (running) finish();
    }

    public void tick() {
        if (running && System.currentTimeMillis() >= endMs) finish();
    }

    private void finish() {
        running = false;
        Bid top = topBid();
        if (top == null) {
            lastAnnounce = "Auction ended: " + aItem + " received no bids.";
            addLog("[Auction] " + aItem + ": no bids");
            status = lastAnnounce;
        } else {
            double profit = top.amount() - aValue;
            d.auctionProfit += profit;
            d.auctionsDone++;
            lastAnnounce = "Auction ended! " + aItem + " won by " + top.bidder() + " for " + Money.fmt(top.amount()) + ".";
            addLog(String.format(Locale.ROOT, "[Auction] %s -> %s for %s (value %s) profit %s",
                    aItem, top.bidder(), Money.fmt(top.amount()), Money.fmt(aValue), Money.fmtSigned(profit)));
            status = lastAnnounce + " Profit " + Money.fmtSigned(profit) + ".";
        }
        notifyLocal(status);
        save();
    }

    /** Called for every incoming game/system chat line. Looks for "<name> !bid 5k". */
    public void onChatLine(String text) {
        if (!running || !d.chatBids || text == null) return;
        Matcher m = CHAT_BID.matcher(text);
        if (!m.find()) return;
        String name = m.group(1);
        String raw = m.group(2).replaceAll("[^0-9a-zA-Z.]+$", "");
        double amount = Money.parse(raw);
        Minecraft.getInstance().execute(() -> {
            String err = placeBid(name, amount);
            if (err != null) status = "Chat bid from " + name + " rejected: " + err;
        });
    }

    // ================= gambling =================

    public double multiplier() {
        double edge = Math.max(0, Math.min(50, Double.isNaN(Money.parse(d.fEdge)) ? 0 : Money.parse(d.fEdge)));
        return BASE_MULT[d.gameIdx] * (1 - edge / 100.0);
    }

    public void play() {
        String player = d.fPlayer.isBlank() ? "Viewer" : d.fPlayer.trim();
        double bet = Money.parse(d.fBet);
        if (Double.isNaN(bet) || bet <= 0) { gameMsg = "Enter a valid bet amount."; lastGameHouseWon = false; return; }

        int g = d.gameIdx;
        int call = Math.min(d.callIdx, CALLS[g].length - 1);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        boolean win;
        String outcome;
        switch (g) {
            case 0 -> {
                int res = r.nextInt(2);
                outcome = "landed " + CALLS[0][res];
                win = res == call;
            }
            case 1 -> {
                int roll = r.nextInt(1, 101);
                outcome = "rolled " + roll;
                win = (roll > 50) == (call == 0);
            }
            default -> {
                int roll = r.nextInt(1, 7);
                outcome = "rolled " + roll;
                win = roll == call + 1;
            }
        }

        double mult = multiplier();
        // Profit from the house's point of view: the stake is kept on a loss, (mult-1)*bet is paid out on a win.
        double houseDelta = win ? -bet * (mult - 1) : bet;
        d.gambleProfit += houseDelta;
        d.gamesPlayed++;
        lastGameHouseWon = !win;

        gameMsg = String.format(Locale.ROOT, "%s bet %s on %s -> %s: %s",
                player, Money.fmt(bet), CALLS[g][call], outcome,
                win ? "WIN, pay " + Money.fmt(bet * mult) : "LOSS, house keeps " + Money.fmt(bet));
        addLog(String.format(Locale.ROOT, "[Gamble] %s | %s | house %s",
                gameMsg, GAMES[g], Money.fmtSigned(houseDelta)));
        save();
    }
}
