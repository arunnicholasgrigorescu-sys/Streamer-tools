package com.streamertools;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.List;

/** The always-on overlay shown to viewers: current auction, countdown, top bid and total profit. */
public final class Hud {
    private Hud() {}

    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int GOLD = 0xFFFFAA00;
    private static final int GREEN = 0xFF55FF55;
    private static final int RED = 0xFFFF5555;

    private record Line(String text, int color) {}

    public static void render(GuiGraphicsExtractor g, DeltaTracker tickDelta) {
        ToolsState s = ToolsState.I;
        if (!s.d.hud) return;
        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;

        List<Line> lines = new ArrayList<>();
        lines.add(new Line("STREAMER TOOLS", GOLD));

        if (s.running) {
            long left = (long) Math.ceil(s.millisLeft() / 1000.0);
            ToolsState.Bid top = s.topBid();
            lines.add(new Line("Auction: " + s.aItem, WHITE));
            lines.add(new Line("Time left: " + Money.fmtTime(left), left <= 10 ? RED : GREEN));
            lines.add(new Line("Min bid: " + Money.fmt(s.aMin) + "   Value: " + Money.fmt(s.aValue), GRAY));
            lines.add(new Line(top == null
                    ? "Top bid: none yet"
                    : "Top bid: " + Money.fmt(top.amount()) + " by " + top.bidder(), WHITE));
            double proj = s.projectedProfit();
            lines.add(new Line("Profit if it ends now: " + Money.fmtSigned(proj), top == null ? GRAY : (proj >= 0 ? GREEN : RED)));
        } else if (!s.lastAnnounce.isEmpty()) {
            lines.add(new Line(s.lastAnnounce, GRAY));
        }

        if (!s.gameMsg.isEmpty()) {
            lines.add(new Line(s.gameMsg, s.lastGameHouseWon ? GREEN : RED));
        }

        double total = s.totalProfit();
        lines.add(new Line("Total profit: " + Money.fmtSigned(total), total >= 0 ? GREEN : RED));
        lines.add(new Line("Auctions " + Money.fmtSigned(s.d.auctionProfit)
                + "  Gambling " + Money.fmtSigned(s.d.gambleProfit), GRAY));

        int pad = 4;
        int lineH = font.lineHeight + 2;
        int maxW = 0;
        for (Line l : lines) maxW = Math.max(maxW, font.width(l.text()));

        int x = 6;
        int y = 6;
        g.fill(x, y, x + maxW + pad * 2, y + lines.size() * lineH + pad * 2 - 2, 0x99000000);
        int ty = y + pad;
        for (Line l : lines) {
            g.text(font, l.text(), x + pad, ty, l.color(), true);
            ty += lineH;
        }
    }
}
