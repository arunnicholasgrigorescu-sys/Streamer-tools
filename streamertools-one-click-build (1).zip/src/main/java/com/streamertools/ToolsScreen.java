package com.streamertools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Control panel with three tabs: Auction (bid wars), Gamble (house games) and Stats (profit and history). */
public class ToolsScreen extends Screen {
    private enum Tab { AUCTION, GAMBLE, STATS }

    private static Tab tab = Tab.AUCTION;

    private static final int COL_W = 300;
    private static final int LABEL_W = 100;

    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int GOLD = 0xFFFFAA00;
    private static final int GREEN = 0xFF55FF55;
    private static final int RED = 0xFFFF5555;

    private record Label(String text, int x, int y) {}

    private final ToolsState s = ToolsState.I;
    private final List<Label> labels = new ArrayList<>();
    private int x0;
    private int infoY;
    private boolean builtRunning;
    private boolean confirmReset;

    public ToolsScreen() {
        super(Component.literal("Streamer Tools"));
    }

    // ================= widget helpers =================

    private EditBox field(int y, String label, String initial, Consumer<String> onChange) {
        int fx = x0 + LABEL_W;
        EditBox box = new EditBox(this.font, fx, y, COL_W - LABEL_W, 20, Component.literal(label));
        box.setMaxLength(64);
        box.setValue(initial == null ? "" : initial);
        box.setResponder(onChange);
        this.addRenderableWidget(box);
        labels.add(new Label(label, x0, y + 6));
        return box;
    }

    private Button button(int x, int y, int w, String text, Runnable action) {
        Button b = Button.builder(Component.literal(text), btn -> action.run())
                .bounds(x, y, w, 20)
                .build();
        this.addRenderableWidget(b);
        return b;
    }

    // ================= layout =================

    @Override
    protected void init() {
        labels.clear();
        builtRunning = s.running;
        x0 = this.width / 2 - COL_W / 2;

        int ty = 14;
        tabButton("Auction", Tab.AUCTION, x0, ty);
        tabButton("Gamble", Tab.GAMBLE, x0 + 74, ty);
        tabButton("Stats", Tab.STATS, x0 + 148, ty);
        button(x0 + 226, ty, 74, "HUD: " + (s.d.hud ? "ON" : "OFF"), () -> {
            s.d.hud = !s.d.hud;
            rebuildWidgets();
        });

        switch (tab) {
            case AUCTION -> auctionTab();
            case GAMBLE -> gambleTab();
            case STATS -> statsTab();
        }
    }

    private void tabButton(String name, Tab t, int x, int y) {
        button(x, y, 70, tab == t ? "[ " + name + " ]" : name, () -> {
            tab = t;
            confirmReset = false;
            rebuildWidgets();
        });
    }

    private void auctionTab() {
        int y = 46;
        if (!s.running) {
            field(y, "Item name", s.d.fItem, v -> s.d.fItem = v); y += 24;
            field(y, "Item value", s.d.fValue, v -> s.d.fValue = v); y += 24;
            field(y, "Minimum bid", s.d.fMin, v -> s.d.fMin = v); y += 24;
            field(y, "Auction time", s.d.fTime, v -> s.d.fTime = v); y += 28;
            button(x0, y, 148, "Use held item", this::useHeldItem);
            button(x0 + 152, y, 148, "Start auction", () -> {
                s.startAuction();
                rebuildWidgets();
            });
            y += 24;
            if (!s.lastAnnounce.isEmpty()) {
                button(x0, y, COL_W, "Copy last announcement", () -> copy(s.lastAnnounce));
                y += 24;
            }
        } else {
            y += 62; // live info lines are drawn here
            field(y, "Bidder name", s.d.fBidder, v -> s.d.fBidder = v); y += 24;
            field(y, "Bid amount", s.d.fBidAmt, v -> s.d.fBidAmt = v); y += 28;
            button(x0, y, COL_W, "Add bid", this::manualBid); y += 24;
            button(x0, y, 148, "End now", () -> {
                s.endAuctionNow();
                rebuildWidgets();
            });
            button(x0 + 152, y, 148, "Cancel", () -> {
                s.cancelAuction();
                rebuildWidgets();
            });
            y += 24;
            button(x0, y, COL_W, "Copy start announcement", () -> copy(s.lastAnnounce));
            y += 24;
        }
        button(x0, y, 148, "Chat !bid: " + (s.d.chatBids ? "ON" : "OFF"), () -> {
            s.d.chatBids = !s.d.chatBids;
            rebuildWidgets();
        });
        button(x0 + 152, y, 148, "Anti-snipe: " + (s.d.antiSnipe ? "ON" : "OFF"), () -> {
            s.d.antiSnipe = !s.d.antiSnipe;
            rebuildWidgets();
        });
        infoY = y + 28;
    }

    private void gambleTab() {
        int y = 46;
        field(y, "Player", s.d.fPlayer, v -> s.d.fPlayer = v); y += 24;
        field(y, "Bet amount", s.d.fBet, v -> s.d.fBet = v); y += 24;
        field(y, "House edge %", s.d.fEdge, v -> s.d.fEdge = v); y += 28;

        int g = s.d.gameIdx;
        int call = Math.min(s.d.callIdx, ToolsState.CALLS[g].length - 1);
        button(x0, y, 148, "Game: " + ToolsState.GAMES[g], () -> {
            s.d.gameIdx = (s.d.gameIdx + 1) % ToolsState.GAMES.length;
            s.d.callIdx = 0;
            rebuildWidgets();
        });
        button(x0 + 152, y, 148, "Call: " + ToolsState.CALLS[g][call], () -> {
            s.d.callIdx = (call + 1) % ToolsState.CALLS[g].length;
            rebuildWidgets();
        });
        y += 24;
        button(x0, y, COL_W, "ROLL!", () -> s.play());
        infoY = y + 28;
    }

    private void statsTab() {
        int by = this.height - 52;
        button(x0, by, 148, confirmReset ? "Click again to confirm" : "Reset stats", () -> {
            if (confirmReset) {
                s.resetStats();
                confirmReset = false;
            } else {
                confirmReset = true;
            }
            rebuildWidgets();
        });
        button(x0 + 152, by, 148, "Copy summary", () -> copy(s.summary()));
        infoY = 48;
    }

    // ================= actions =================

    private void useHeldItem() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        ItemStack stack = mc.player.getMainHandItem();
        if (stack.isEmpty()) {
            s.status = "Hold an item in your main hand first.";
            return;
        }
        String name = stack.getHoverName().getString();
        if (stack.getCount() > 1) name += " x" + stack.getCount();
        s.d.fItem = name;
        s.status = "Item set to " + name + ". Enter its value and press Start.";
        rebuildWidgets();
    }

    private void manualBid() {
        double amt = Money.parse(s.d.fBidAmt);
        String err = s.placeBid(s.d.fBidder, amt);
        if (err != null) {
            s.status = "Bid rejected: " + err;
        } else {
            s.d.fBidAmt = "";
            rebuildWidgets();
        }
    }

    private void copy(String text) {
        Minecraft.getInstance().keyboardHandler.setClipboard(text);
        s.status = "Copied to clipboard.";
    }

    // ================= screen lifecycle =================

    @Override
    public void tick() {
        super.tick();
        if (builtRunning != s.running) rebuildWidgets();
    }

    @Override
    public void removed() {
        s.save();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ================= drawing =================

    private void text(GuiGraphicsExtractor g, String str, int x, int y, int color) {
        g.text(this.font, str, x, y, color, true);
    }

    private static int profitColor(double v) {
        return v >= 0 ? GREEN : RED;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);

        for (Label l : labels) text(g, l.text(), l.x(), l.y(), GRAY);

        switch (tab) {
            case AUCTION -> drawAuction(g);
            case GAMBLE -> drawGamble(g);
            case STATS -> drawStats(g);
        }

        if (!s.status.isEmpty()) {
            text(g, s.status, x0, this.height - 18, GOLD);
        }
    }

    private void drawAuction(GuiGraphicsExtractor g) {
        if (s.running) {
            int y = 46;
            long left = (long) Math.ceil(s.millisLeft() / 1000.0);
            ToolsState.Bid top = s.topBid();
            text(g, "Item: " + s.aItem + "   (value " + Money.fmt(s.aValue) + ", min " + Money.fmt(s.aMin) + ")", x0, y, WHITE);
            text(g, "Time left: " + Money.fmtTime(left), x0, y + 13, left <= 10 ? RED : GREEN);
            text(g, top == null ? "Top bid: none yet" : "Top bid: " + Money.fmt(top.amount()) + " by " + top.bidder(), x0, y + 26, WHITE);
            double proj = s.projectedProfit();
            text(g, "Profit if it ends now: " + Money.fmtSigned(proj), x0, y + 39, top == null ? GRAY : profitColor(proj));

            text(g, "Recent bids:", x0, infoY, GRAY);
            int shown = 0;
            for (int i = s.bids.size() - 1; i >= 0 && shown < 5; i--, shown++) {
                ToolsState.Bid b = s.bids.get(i);
                text(g, b.bidder() + "  " + Money.fmt(b.amount()), x0 + 8, infoY + 12 + shown * 11, WHITE);
            }
        } else {
            text(g, "Tip: amounts accept k / m / b (e.g. 2.5m). Time accepts 90, 5m, 1h30m or 1:30.", x0, infoY, GRAY);
            text(g, "Viewers can bid by typing: !bid 5k  (read from chat while an auction runs)", x0, infoY + 12, GRAY);
            text(g, "Profit per auction = winning bid - item value.", x0, infoY + 24, GRAY);
        }
    }

    private void drawGamble(GuiGraphicsExtractor g) {
        text(g, String.format(java.util.Locale.ROOT, "Payout: x%.2f of the bet on a win (stake included).", s.multiplier()), x0, infoY, GRAY);
        if (!s.gameMsg.isEmpty()) {
            text(g, s.gameMsg, x0, infoY + 14, s.lastGameHouseWon ? GREEN : RED);
        }
        text(g, "House profit: " + Money.fmtSigned(s.d.gambleProfit) + "  (" + s.d.gamesPlayed + " games)", x0, infoY + 30, profitColor(s.d.gambleProfit));
        text(g, "Payouts are paid by you manually. This tool never sends commands.", x0, infoY + 44, GRAY);

        int shown = 0;
        for (String line : s.d.log) {
            if (!line.startsWith("[Gamble]")) continue;
            if (shown >= 4) break;
            text(g, trim(line), x0, infoY + 62 + shown * 11, WHITE);
            shown++;
        }
    }

    private void drawStats(GuiGraphicsExtractor g) {
        int y = infoY;
        text(g, "Total profit: " + Money.fmtSigned(s.totalProfit()), x0, y, profitColor(s.totalProfit()));
        text(g, "Auctions: " + Money.fmtSigned(s.d.auctionProfit) + "  (" + s.d.auctionsDone + " sold)", x0, y + 13, profitColor(s.d.auctionProfit));
        text(g, "Gambling: " + Money.fmtSigned(s.d.gambleProfit) + "  (" + s.d.gamesPlayed + " games)", x0, y + 26, profitColor(s.d.gambleProfit));
        text(g, "History:", x0, y + 44, GRAY);
        int rows = Math.max(1, (this.height - 52 - (y + 58)) / 11);
        int i = 0;
        for (String line : s.d.log) {
            if (i >= rows) break;
            text(g, trim(line), x0, y + 58 + i * 11, WHITE);
            i++;
        }
        if (s.d.log.isEmpty()) text(g, "Nothing yet.", x0, y + 58, GRAY);
    }

    /** Keeps a log line inside the panel. */
    private String trim(String line) {
        int max = COL_W + 60;
        if (this.font.width(line) <= max) return line;
        String t = line;
        while (t.length() > 4 && this.font.width(t + "...") > max) t = t.substring(0, t.length() - 1);
        return t + "...";
    }
}
