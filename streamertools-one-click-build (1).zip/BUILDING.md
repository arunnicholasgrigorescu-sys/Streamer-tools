# Build on Minecraft Java 26.3

This project targets Minecraft 26.3, Fabric Loader 0.19.5+, Java 25 (JDK 25 required to run the build and compile), Fabric API 0.164.0+26.3, and Fabric Loom 1.18-SNAPSHOT.

## Build locally

1. Install a JDK 25 distribution and Gradle 9.6 or newer.
2. Open a terminal in this folder (the folder containing `build.gradle`).
3. Run `gradle clean build`.
4. The mod jar should be in `build/libs/streamertools-1.0.0.jar`.
5. Install it with Fabric Loader 0.19.5+ and Fabric API 0.164.0+26.3 in the Minecraft 26.3 `mods` folder.

## Build through GitHub Actions

The included workflow builds on GitHub when you push this project to a GitHub repository or manually run the workflow. Download the `streamertools-jar` artifact from the workflow run's Artifacts section. This requires a GitHub account and uploading the source project to a repository you control.

A successful compile is not the same as a confirmed in-game test. Test on a separate Minecraft profile before using it on a server.
