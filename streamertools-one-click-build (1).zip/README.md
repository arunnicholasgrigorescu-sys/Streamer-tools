# Streamer Tools (Fabric, Minecraft 26.3)

Client-side mod. Needs Fabric Loader 0.19.5+ and Fabric API for 26.3. It runs on any server (DonutSMP included) because it only
reads chat and draws on your own screen. It never sends chat, commands or payments.

## Build the .jar

1. Install JDK 25 (e.g. Temurin 25) and Gradle 9.6 or newer (or open this folder in IntelliJ IDEA, which sets both up).
2. In this folder run:

       gradle build

3. Your mod is `build/libs/streamertools-1.0.0.jar` (ignore the `-sources` jar).
4. Put it in `.minecraft/mods` together with Fabric API 0.164.0+26.3 (or any 26.3 build).

If Gradle complains about the Loom version, change `loom_version` in `gradle.properties` to the newest 1.18.x.

## Using it

- `U` opens the panel, `I` toggles the HUD overlay (both can be rebound in Controls > Streamer Tools).
- Amounts accept `k`, `m`, `b` (e.g. `2.5m`). Time accepts `90`, `5m`, `1h30m` or `1:30`.

### Auction tab (bid wars)
Item name (or "Use held item"), item value, minimum bid, auction time, then Start.
Bids come from the Add bid button or from viewers typing `!bid 5k` in chat (needs a chat line that contains
their name followed by `!bid <amount>`). Anti-snipe adds 10 seconds when a bid lands in the last 10 seconds.
Profit per auction = winning bid - item value. The HUD shows item, countdown, top bidder and profit.

### Gamble tab
House-run Coin Flip, High/Low and Pick-a-Number. Enter the player, the bet and a house edge, choose the game and the call, press ROLL.
The result and the house profit are tracked. You pay winners yourself.

### Stats tab
Total, auction and gambling profit, history, reset, and a copy-to-clipboard summary. Everything is saved in `config/streamertools.json`.

Check DonutSMP's rules before running gambling for other players on the server.
